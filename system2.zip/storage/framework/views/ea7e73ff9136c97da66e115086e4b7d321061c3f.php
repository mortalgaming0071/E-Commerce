<div class="dashboard-stat2 bordered">
    <div class="display">
        <div class="number">
            <h3 class="font-red-haze">
                <span data-counter="counterup" data-value="<?php echo e($count['products']); ?>">0</span>
            </h3>
            <small><?php echo e(trans('plugins/ecommerce::reports.count.products')); ?></small>
        </div>
        <div class="icon">
            <i class="fab fa-product-hunt"></i>
        </div>
    </div>

</div><?php /**PATH C:\xampp\htdocs\laravel-ecommerce-system\platform/plugins/ecommerce/resources/views//reports/partials/count-products.blade.php ENDPATH**/ ?>