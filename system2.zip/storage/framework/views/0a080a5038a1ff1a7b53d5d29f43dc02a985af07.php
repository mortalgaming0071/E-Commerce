<div class="visual-swatches-wrapper widget--colors widget-filter-item" data-type="visual">
    <h4 class="widget__title"><?php echo e(__('By')); ?> <?php echo e($set->title); ?></h4>
    <div class="widget__content">
        <div class="attribute-values">
            <ul class="visual-swatch color-swatch">
                <?php $__currentLoopData = $attributes->where('attribute_set_id', $set->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attribute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li data-slug="<?php echo e($attribute->slug); ?>"
                        data-toggle="tooltip"
                        data-placement="top"
                        title="<?php echo e($attribute->title); ?>">
                        <div class="custom-checkbox">
                            <label>
                                <input class="form-control product-filter-item" type="checkbox" name="attributes[]" value="<?php echo e($attribute->id); ?>" <?php echo e(in_array($attribute->id, $selected) ? 'checked' : ''); ?>>
                                <span style="<?php echo e($attribute->image ? 'background-image: url(' . RvMedia::getImageUrl($attribute->image) . ');' : 'background-color: ' . $attribute->color . ';'); ?>"></span>
                            </label>
                        </div>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\laravel-ecommerce-system\platform/themes/shopwise/views/ecommerce/attributes/_layouts-filter/visual.blade.php ENDPATH**/ ?>