<div class="form-group">
    <label class="control-label">Image 1 (540x300)</label>
    <?php echo Form::mediaImage('image1', null, ['data-shortcode-attribute' => 'image1']); ?>

</div>

<div class="form-group">
    <label class="control-label">URL 1</label>
    <input type="text" name="url1" data-shortcode-attribute="url1" class="form-control" placeholder="URL 1">
</div>

<div class="form-group">
    <label class="control-label">Image 2 (540x300)</label>
    <?php echo Form::mediaImage('image2', null, ['data-shortcode-attribute' => 'image2']); ?>

</div>

<div class="form-group">
    <label class="control-label">URL 2</label>
    <input type="text" name="url2" data-shortcode-attribute="url2" class="form-control" placeholder="URL 2">
</div>

<div class="form-group">
    <label class="control-label">Image 3 (540x300)</label>
    <?php echo Form::mediaImage('image3', null, ['data-shortcode-attribute' => 'image3']); ?>

</div>

<div class="form-group">
    <label class="control-label">URL 3</label>
    <input type="text" name="url3" data-shortcode-attribute="url3" class="form-control" placeholder="URL 3">
</div>
<?php /**PATH C:\xampp\htdocs\laravel-ecommerce-system\platform/themes/shopwise/partials/shortcodes/banners-admin-config.blade.php ENDPATH**/ ?>