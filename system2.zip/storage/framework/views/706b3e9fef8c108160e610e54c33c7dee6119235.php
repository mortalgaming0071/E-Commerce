<?php $__env->startSection('content'); ?>
    <?php Theme::set('pageName', __('Order information')) ?>
    <div class="card">
        <div class="card-header">
            <h3><?php echo e(__('Order information')); ?></h3>
        </div>
        <div class="card-body">
            <div class="customer-order-detail">
                <div class="row">
                    <div class="col-md-6">
                        <div class="order-slogan">
                            <img width="100" src="<?php echo e(RvMedia::getImageUrl(theme_option('logo'))); ?>"
                                 alt="<?php echo e(theme_option('site_title')); ?>">
                            <br/>
                            <?php echo e(setting('contact_address')); ?>

                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="order-meta">
                            <p><span><?php echo e(__('Order number')); ?>:</span> <span
                                    class="order-detail-value"><?php echo e(get_order_code($order->id)); ?></span></p>
                            <span><?php echo e(__('Time')); ?>:</span> <span
                                class="order-detail-value"><?php echo e($order->created_at->translatedFormat('M d, Y h:m')); ?></span>
                        </div>
                    </div>
                </div>

                <h6><?php echo e(__('Order information')); ?></h6>
                <div class="col-12">
                    <span><?php echo e(__('Order status')); ?>:</span> <span
                        class="order-detail-value"><?php echo $order->status->toHtml(); ?></span>
                </div>

                <div class="col-12">
                    <span><?php echo e(__('Payment method')); ?>:</span> <span
                        class="order-detail-value"> <?php echo $order->payment->payment_channel->label(); ?> </span>
                    <br>
                    <span><?php echo e(__('Payment status')); ?>:</span> <span
                        class="order-detail-value"><?php echo $order->payment->status->toHtml(); ?></span>
                </div>

                <div class="col-12">
                    <span><?php echo e(__('Amount')); ?>:</span> <span
                        class="order-detail-value"> <?php echo e(format_price($order->amount, $order->currency_id)); ?> </span>
                </div>

                <?php if(EcommerceHelper::isTaxEnabled()): ?>
                    <div class="col-12">
                        <span><?php echo e(__('Tax')); ?>:</span> <span
                            class="order-detail-value"> <?php echo e(format_price($order->tax_amount, $order->currency_id)); ?> </span>
                    </div>
                <?php endif; ?>

                <div class="col-12">
                    <span><?php echo e(__('Shipping fee')); ?>:</span> <span
                        class="order-detail-value">  <?php echo e(format_price($order->shipping_amount, $order->currency_id)); ?> </span>
                </div>

                <div class="col-12">
                    <?php if($order->description): ?>
                        <span><?php echo e(__('Note')); ?>:</span> <span class="order-detail-value text-warning"><?php echo e($order->description); ?> </span>&nbsp;
                    <?php endif; ?>
                </div>
                <br>
                <h6><?php echo e(__('Customer information')); ?></h6>

                <div class="col-12">
                    <span><?php echo e(__('Full Name')); ?>:</span> <span class="order-detail-value"><?php echo e($order->address->name); ?> </span>
                </div>

                <div class="col-12">
                    <span><?php echo e(__('Phone')); ?>:</span> <span class="order-detail-value"><?php echo e($order->address->phone); ?> </span>
                </div>

                <div class="col-12">
                    <span><?php echo e(__('Address')); ?>:</span> <span
                        class="order-detail-value"> <?php echo e($order->address->address); ?> </span>
                </div>

                <div class="col-12">
                    <span><?php echo e(__('City')); ?>:</span> <span
                        class="order-detail-value"><?php echo e($order->address->city); ?> </span>
                </div>
                <div class="col-12">
                    <span><?php echo e(__('State')); ?>:</span> <span
                        class="order-detail-value"> <?php echo e($order->address->state); ?> </span>
                </div>
                <br>
                <h6><?php echo e(__('Order detail')); ?></h6>
                <div class="col-12">
                    <div class="table-responsive">
                        <table class="table table-striped table-hover">
                            <thead>
                            <tr>
                                <th class="text-center">#</th>
                                <th class="text-center"><?php echo e(__('Image')); ?></th>
                                <th><?php echo e(__('Product')); ?></th>
                                <th class="text-center"><?php echo e(__('Amount')); ?></th>
                                <th class="text-right" style="width: 100px"><?php echo e(__('Quantity')); ?></th>
                                <th class="price text-right"><?php echo e(__('Total')); ?></th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $order->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $orderProduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $product = get_products([
                                        'condition' => [
                                            'ec_products.status' => \Botble\Base\Enums\BaseStatusEnum::PUBLISHED,
                                            'ec_products.id' => $orderProduct->product_id,
                                        ],
                                        'take' => 1,
                                        'select' => [
                                            'ec_products.id',
                                            'ec_products.images',
                                            'ec_products.name',
                                            'ec_products.price',
                                            'ec_products.sale_price',
                                            'ec_products.sale_type',
                                            'ec_products.start_date',
                                            'ec_products.end_date',
                                            'ec_products.sku',
                                            'ec_products.is_variation',
                                        ],
                                    ]);

                                ?>
                                <tr>
                                    <td class="text-center"><?php echo e($key + 1); ?></td>
                                    <td class="text-center">
                                        <?php if($product): ?>
                                            <img src="<?php echo e(RvMedia::getImageUrl($product->image, 'thumb', false, RvMedia::getDefaultImage())); ?>" width="50" alt="<?php echo e($product->name); ?>">
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php echo e($orderProduct->product_name); ?> <?php if($product && $product->sku): ?> (<?php echo e($product->sku); ?>) <?php endif; ?>
                                        <?php if($product && $product->is_variation): ?>
                                            <p>
                                                <small>
                                                    <?php $attributes = get_product_attributes($product->id) ?>
                                                    <?php if(!empty($attributes)): ?>
                                                        <?php $__currentLoopData = $attributes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attribute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php echo e($attribute->attribute_set_title); ?>: <?php echo e($attribute->title); ?><?php if(!$loop->last): ?>, <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endif; ?>
                                                </small>
                                            </p>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e(format_price($orderProduct->price)); ?></td>
                                    <td class="text-center"><?php echo e($orderProduct->qty); ?></td>
                                    <td class="money text-right">
                                        <strong>
                                            <?php echo e(format_price($orderProduct->price * $orderProduct->qty)); ?>

                                        </strong>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <br>
                <div>
                    <a href="<?php echo e(route('customer.print-order', $order->id)); ?>" class="btn btn-fill-out btn-sm"><?php echo e(__('Print order')); ?></a>
                    <?php if($order->canBeCanceled()): ?>
                        <a href="<?php echo e(route('customer.orders.cancel', $order->id)); ?>" class="btn btn-dark btn-sm"><?php echo e(__('Cancel order')); ?></a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make(Theme::getThemeNamespace() . '::views.ecommerce.customers.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-ecommerce-system\platform/themes/shopwise/views/ecommerce/customers/orders/view.blade.php ENDPATH**/ ?>