<div class="help-ts">
    <i class="fa fa-info-circle"></i>
    <span><?php echo $content; ?></span>
</div><?php /**PATH C:\xampp\htdocs\laravel-ecommerce-system\platform/core/base/resources/views//forms/partials/helper.blade.php ENDPATH**/ ?>