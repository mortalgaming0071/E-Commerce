<p><?php echo e(trans('core/setting::setting.test_email_description')); ?></p>

<div class="form-group">
    <input type="email" class="form-control" name="email" placeholder="<?php echo e(trans('core/setting::setting.test_email_input_placeholder')); ?>">
</div><?php /**PATH C:\xampp\htdocs\laravel-ecommerce-system\platform/core/setting/resources/views//test-email.blade.php ENDPATH**/ ?>