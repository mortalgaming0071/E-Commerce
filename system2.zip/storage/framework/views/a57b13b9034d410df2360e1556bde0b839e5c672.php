<?php if(!empty($data)): ?>
    <div id="<?php echo e($context); ?>-sortables" class="meta-box-sortables">
        <?php echo $data; ?>

    </div>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\laravel-ecommerce-system\platform/core/base/resources/views//elements/meta-box.blade.php ENDPATH**/ ?>