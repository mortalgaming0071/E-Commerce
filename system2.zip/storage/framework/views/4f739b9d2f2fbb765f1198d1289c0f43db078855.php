<?php echo Html::link($href, trans('core/table::table.delete'), ['class' => 'delete-many-entry-trigger', 'data-class-item' => $data_class]); ?>

<?php /**PATH C:\xampp\htdocs\laravel-ecommerce-system\platform/core/table/resources/views//partials/delete.blade.php ENDPATH**/ ?>