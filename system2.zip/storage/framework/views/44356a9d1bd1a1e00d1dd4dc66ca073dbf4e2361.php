<div class="order-customer-info">
    <h3> <?php echo e(__('Customer information')); ?></h3>
    <p>
        <span class="d-inline-block"><?php echo e(__('Full name')); ?>:</span>
        <span class="order-customer-info-meta"><?php echo e($order->address->name); ?></span>
    </p>
    <p>
        <span class="d-inline-block"><?php echo e(__('Phone')); ?>:</span>
        <span class="order-customer-info-meta"><?php echo e($order->address->phone); ?></span>
    </p>
    <p>
        <span class="d-inline-block"><?php echo e(__('Email')); ?>:</span>
        <span class="order-customer-info-meta"><?php echo e($order->address->email); ?></span>
    </p>
    <p>
        <span class="d-inline-block"><?php echo e(__('Address')); ?>:</span>
        <span class="order-customer-info-meta"><?php echo e($order->full_address); ?></span>
    </p>
    <p>
        <span class="d-inline-block"><?php echo e(__('Shipping method')); ?>:</span>
        <span class="order-customer-info-meta"><?php echo e($order->shipping_method_name); ?> - <?php if($order->shipping_amount > 0): ?> <?php echo e(format_price($order->shipping_amount)); ?> <?php else: ?> <strong><?php echo e(__('Free shipping')); ?></strong> <?php endif; ?></span>
    </p>
    <p>
        <span class="d-inline-block"><?php echo e(__('Payment method')); ?>:</span>
        <span class="order-customer-info-meta"><?php echo e($order->payment->payment_channel->label()); ?></span>
    </p>
    <p>
        <span class="d-inline-block"><?php echo e(__('Payment status')); ?>:</span>
        <span class="order-customer-info-meta" style="text-transform: uppercase"><?php echo $order->payment->status->toHtml(); ?></span>
    </p>
</div>
<?php /**PATH C:\xampp\htdocs\laravel-ecommerce-system\platform/plugins/ecommerce/resources/views//orders/thank-you/customer-info.blade.php ENDPATH**/ ?>