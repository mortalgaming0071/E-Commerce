<?php Theme::set('pageName', __('Wishlist')) ?>

<div class="section">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="table-responsive shop_cart_table wishlist-table">
                    <table class="table">
                        <thead>
                        <tr>
                            <th class="product-thumbnail"><?php echo e(__('Image')); ?></th>
                            <th class="product-name"><?php echo e(__('Product')); ?></th>
                            <th class="product-price"><?php echo e(__('Price')); ?></th>
                            <th class="product-subtotal"><?php echo e(__('Add to cart')); ?></th>
                            <th class="product-remove"><?php echo e(__('Remove')); ?></th>
                        </tr>
                        </thead>
                        <tbody>
                            <?php if(auth('customer')->check()): ?>
                                <?php if(count($wishlist) > 0 && $wishlist->count() > 0): ?>
                                    <?php $__currentLoopData = $wishlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php $item = $item->product; ?>
                                        <tr>
                                            <td class="product-thumbnail">
                                                <img alt="<?php echo e($item->name); ?>" width="50" height="70" class="img-fluid"
                                                     style="max-height: 75px"
                                                     src="<?php echo e(RvMedia::getImageUrl($item->image, 'thumb', false, RvMedia::getDefaultImage())); ?>">
                                            </td>
                                            <td class="product-name" data-title="<?php echo e(__('Product')); ?>">
                                                <a href="<?php echo e($item->original_product->url); ?>"><?php echo e($item->name); ?></a>
                                            </td>
                                            <td class="product-price">
                                                <div class="product__price <?php if($item->front_sale_price != $item->price): ?> sale <?php endif; ?>">
                                                    <span><?php echo e(format_price($item->front_sale_price_with_taxes)); ?></span>
                                                    <?php if($item->front_sale_price != $item->price): ?>
                                                        <small><del><?php echo e(format_price($item->price_with_taxes)); ?></del></small>
                                                    <?php endif; ?>
                                                </div>
                                            </td>
                                            <td class="product-remove" data-title="<?php echo e(__('Add to cart')); ?>">
                                                <a class="btn btn-fill-out btn-sm add-to-cart-button" data-id="<?php echo e($item->id); ?>" href="#" data-url="<?php echo e(route('public.cart.add-to-cart')); ?>"><?php echo e(__('Add to cart')); ?></a>
                                            </td>
                                            <td class="product-remove" data-title="<?php echo e(__('Remove')); ?>">
                                                <a class="btn btn-dark btn-sm js-remove-from-wishlist-button" href="#" data-url="<?php echo e(route('public.wishlist.remove', $item->id)); ?>"><?php echo e(__('Remove')); ?></a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="4" class="text-center"><?php echo e(__('No product in wishlist!')); ?></td>
                                    </tr>
                                <?php endif; ?>
                            <?php else: ?>
                                <?php if(Cart::instance('wishlist')->count()): ?>
                                    <?php $__currentLoopData = Cart::instance('wishlist')->content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cartItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $item = app(\Botble\Ecommerce\Repositories\Interfaces\ProductInterface::class)->findById($cartItem->id);
                                        ?>
                                        <?php if(!empty($item)): ?>
                                            <tr>
                                                <td class="product-thumbnail">
                                                    <img alt="<?php echo e($item->name); ?>" width="50" height="70" class="img-fluid"
                                                         style="max-height: 75px"
                                                         src="<?php echo e(RvMedia::getImageUrl($item->image, 'thumb', false, RvMedia::getDefaultImage())); ?>">
                                                </td>
                                                <td class="product-name" data-title="<?php echo e(__('Product')); ?>">
                                                    <a href="<?php echo e($item->original_product->url); ?>"><?php echo e($item->name); ?></a>
                                                </td>
                                                <td class="product-price" data-title="<?php echo e(__('Price')); ?>">
                                                    <div class="product__price <?php if($item->front_sale_price != $item->price): ?> sale <?php endif; ?>">
                                                        <span><?php echo e(format_price($item->front_sale_price_with_taxes)); ?></span>
                                                        <?php if($item->front_sale_price != $item->price): ?>
                                                            <small><del><?php echo e(format_price($item->price_with_taxes)); ?></del></small>
                                                        <?php endif; ?>
                                                    </div>
                                                </td>
                                                <td class="product-remove" data-title="<?php echo e(__('Add to cart')); ?>">
                                                    <a class="btn btn-fill-out btn-sm add-to-cart-button" data-id="<?php echo e($item->id); ?>" href="<?php echo e(route('public.cart.add-to-cart')); ?>"><?php echo e(__('Add to cart')); ?></a>
                                                </td>
                                                <td class="product-remove" data-title="<?php echo e(__('Remove')); ?>">
                                                    <a class="btn btn-dark btn-sm js-remove-from-wishlist-button" href="#" data-url="<?php echo e(route('public.wishlist.remove', $item->id)); ?>"><?php echo e(__('Remove')); ?></a>
                                                </td>
                                            </tr>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="4" class="text-center"><?php echo e(__('No product in wishlist!')); ?></td>
                                    </tr>
                                <?php endif; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <?php if(auth('customer')->check()): ?>
                    <div class="mt-3 justify-content-center pagination_style1">
                        <?php echo $wishlist->links(); ?>

                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\laravel-ecommerce-system\platform/themes/shopwise/views/ecommerce/wishlist.blade.php ENDPATH**/ ?>