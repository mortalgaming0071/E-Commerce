<?php $__env->startSection('content'); ?>
    <?php Theme::set('pageName', __('Orders')) ?>

    <div class="card">
        <div class="card-header">
            <h3><?php echo e(__('Orders')); ?></h3>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table">
                    <thead>
                    <tr>
                        <th><?php echo e(__('ID number')); ?></th>
                        <th><?php echo e(__('Date')); ?></th>
                        <th><?php echo e(__('Total')); ?></th>
                        <th><?php echo e(__('Status')); ?></th>
                        <th><?php echo e(__('Actions')); ?></th>
                    </tr>
                    </thead>
                    <tbody>
                        <?php if(count($orders) > 0): ?>
                            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e(get_order_code($order->id)); ?></td>
                                    <td><?php echo e($order->created_at->translatedFormat('M d, Y h:m')); ?></td>
                                    <td><?php echo e(format_price($order->amount)); ?></td>
                                    <td><?php echo $order->status->toHtml(); ?></td>
                                    <td>
                                        <a class="btn btn-fill-out btn-sm" href="<?php echo e(route('customer.orders.view', $order->id)); ?>"><?php echo e(__('View')); ?></a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="5" class="text-center"><?php echo e(__('No orders!')); ?></td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <div class="mt-3 justify-content-center pagination_style1">
                <?php echo $orders->links(); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make(Theme::getThemeNamespace() . '::views.ecommerce.customers.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-ecommerce-system\platform/themes/shopwise/views/ecommerce/customers/orders/list.blade.php ENDPATH**/ ?>