<?php
    Arr::set($attributes, 'class', Arr::get($attributes, 'class') . ' icon-select');
?>

<?php echo Form::customSelect($name, [$value => $value], $value, $attributes); ?>


<?php if (! $__env->hasRenderedOnce('67990ebc-762c-4c67-a6e5-301a99c95401')): $__env->markAsRenderedOnce('67990ebc-762c-4c67-a6e5-301a99c95401'); ?>
    <?php $__env->startPush('header'); ?>
        <link media="all" type="text/css" rel="stylesheet" href="<?php echo e(Theme::asset()->url('css/flaticon.css')); ?>">
        <link media="all" type="text/css" rel="stylesheet" href="<?php echo e(Theme::asset()->url('css/ionicons.min.css')); ?>">
        <link media="all" type="text/css" rel="stylesheet" href="<?php echo e(Theme::asset()->url('css/linearicons.css')); ?>">
        <script src="<?php echo e(Theme::asset()->url('js/icons-field.js')); ?>?v=1.0.1"></script>
    <?php $__env->stopPush(); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\laravel-ecommerce-system\platform/themes/shopwise/partials/icons-field.blade.php ENDPATH**/ ?>