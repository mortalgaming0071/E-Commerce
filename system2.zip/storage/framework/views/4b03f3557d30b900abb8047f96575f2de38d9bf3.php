<tr class="<?php if(!empty($odd) && $odd == true): ?> odd <?php else: ?> even <?php endif; ?>">
    <td><?php echo e($data['name']); ?></td>
    <td><?php echo e($data['description']); ?></td>
    <td><?php echo e(human_file_size(get_backup_size($key))); ?></td>
    <td style="width: 250px;"><?php echo e($data['date']); ?></td>
    <td style="width: 150px;">
        <?php if($backupManager->isDatabaseBackupAvailable($key)): ?>
            <a href="<?php echo e(route('backups.download.database', $key)); ?>" class="text-success" data-toggle="tooltip" title="<?php echo e(trans('plugins/backup::backup.download_database')); ?>"><i class="icon icon-database"></i></a>
        <?php endif; ?>

        <a href="<?php echo e(route('backups.download.uploads.folder', $key)); ?>" class="text-primary" data-toggle="tooltip" title="<?php echo e(trans('plugins/backup::backup.download_uploads_folder')); ?>"><i class="icon icon-download"></i></a>

        <?php if(auth()->user()->hasPermission('backups.destroy')): ?>
            <a href="#" data-section="<?php echo e(route('backups.destroy', $key)); ?>" class="text-danger deleteDialog" data-toggle="tooltip" title="<?php echo e(trans('core/base::tables.delete_entry')); ?>"><i class="icon icon-trash"></i></a>
        <?php endif; ?>

        <?php if(auth()->user()->hasPermission('backups.restore')): ?>
            <a href="#" data-section="<?php echo e(route('backups.restore', $key)); ?>" class="text-info restoreBackup" data-toggle="tooltip" title="<?php echo e(trans('plugins/backup::backup.restore_tooltip')); ?>"><i class="icon icon-publish"></i></a>
        <?php endif; ?>
    </td>
</tr>
<?php /**PATH C:\xampp\htdocs\laravel-ecommerce-system\platform/plugins/backup/resources/views//partials/backup-item.blade.php ENDPATH**/ ?>