<div class="text-left">
    <div class="checkbox checkbox-primary table-checkbox">
        <input type="checkbox" class="checkboxes" name="id[]" value="<?php echo e($id); ?>"/>
    </div>
</div><?php /**PATH C:\xampp\htdocs\laravel-ecommerce-system\platform/core/table/resources/views//partials/checkbox.blade.php ENDPATH**/ ?>