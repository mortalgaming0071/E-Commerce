<?php $__env->startSection('content'); ?>
    <?php echo Form::open(['route' => ['setting.email.template.store']]); ?>

    <div class="max-width-1200">
        <div class="flexbox-annotated-section">
            <div class="flexbox-annotated-section-annotation">
                <div class="annotated-section-title pd-all-20">
                    <h2><?php echo e(trans('core/setting::setting.email.title')); ?></h2>
                </div>
                <div class="annotated-section-description pd-all-20 p-none-t">
                    <p class="color-note">
                        <?php echo clean(trans('core/setting::setting.email.description')); ?>

                    </p>
                    <div class="available-variable">
                        <?php $__currentLoopData = EmailHandler::getVariables('core'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coreKey => $coreVariable): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <p><span class="text-danger"><?php echo e($coreKey); ?></span>: <?php echo e($coreVariable); ?></p>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = EmailHandler::getVariables($pluginData['name']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $moduleKey => $moduleVariable): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <p><span class="text-danger"><?php echo e($moduleKey); ?></span>: <?php echo e(trans($moduleVariable)); ?></p>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>

            <div class="flexbox-annotated-section-content">
                <div class="wrapper-content pd-all-20 email-template-edit-wrap">
                    <?php if($emailSubject): ?>
                        <div class="form-group">
                            <label class="text-title-field"
                                   for="email_subject">
                                <?php echo e(trans('core/setting::setting.email.subject')); ?>

                            </label>
                            <input type="hidden" name="email_subject_key"
                                   value="<?php echo e(get_setting_email_subject_key($pluginData['type'], $pluginData['name'], $pluginData['template_file'])); ?>">
                            <input data-counter="300" type="text" class="next-input"
                                   name="email_subject"
                                   id="email_subject"
                                   value="<?php echo e($emailSubject); ?>">
                        </div>
                    <?php endif; ?>
                    <div class="form-group">
                        <input type="hidden" name="template_path" value="<?php echo e(get_setting_email_template_path($pluginData['name'], $pluginData['template_file'])); ?>">
                        <label class="text-title-field"
                               for="email_content"><?php echo e(trans('core/setting::setting.email.content')); ?></label>
                        <textarea id="mail-template-editor" name="email_content" class="form-control" style="overflow-y:scroll; height: 500px;"><?php echo e($emailContent); ?></textarea>
                    </div>
                </div>
            </div>

        </div>

        <div class="flexbox-annotated-section" style="border: none">
            <div class="flexbox-annotated-section-annotation">
                &nbsp;
            </div>
            <div class="flexbox-annotated-section-content">
                <a href="<?php echo e(route('settings.email')); ?>" class="btn btn-secondary"><?php echo e(trans('core/setting::setting.email.back')); ?></a>
                <a class="btn btn-warning btn-trigger-reset-to-default" data-target="<?php echo e(route('setting.email.template.reset-to-default')); ?>"><?php echo e(trans('core/setting::setting.email.reset_to_default')); ?></a>
                <button class="btn btn-info" type="submit" name="submit"><?php echo e(trans('core/setting::setting.save_settings')); ?></button>
            </div>
        </div>
    </div>
    <?php echo Form::close(); ?>


    <?php echo Form::modalAction('reset-template-to-default-modal', trans('core/setting::setting.email.confirm_reset'), 'info', trans('core/setting::setting.email.confirm_message'), 'reset-template-to-default-button', trans('core/setting::setting.email.continue')); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('core/base::layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-ecommerce-system\platform/core/setting/resources/views//email-template-edit.blade.php ENDPATH**/ ?>