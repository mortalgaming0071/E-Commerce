<li class="nav-item">
    <a href="#tab_history" class="nav-link" data-toggle="tab"><?php echo e(trans('core/base::tabs.revision')); ?> </a>
</li><?php /**PATH C:\xampp\htdocs\laravel-ecommerce-system\platform/packages/revision/resources/views//history-tab.blade.php ENDPATH**/ ?>