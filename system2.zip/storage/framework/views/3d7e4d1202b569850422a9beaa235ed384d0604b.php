<?php Theme::set('pageName', __('Blog')) ?>

<div class="section">
    <div class="container">
        <div class="row">
            <div class="col-xl-9">
                <div class="single_post">
                    <h2 class="blog_title"><?php echo e($post->name); ?></h2>
                    <ul class="list_none blog_meta">
                        <li><i class="ti-calendar"></i> <?php echo e($post->created_at->translatedFormat('M d, Y')); ?></li>
                        <li><i class="ti-pencil-alt"></i>
                            <?php if(!$post->categories->isEmpty()): ?>
                                <?php $__currentLoopData = $post->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a href="<?php echo e($category->url); ?>"><?php echo e($category->name); ?></a><?php if(!$loop->last): ?>,<?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </li>
                        <li><i class="ti-eye"></i> <?php echo e(number_format($post->views)); ?> <?php echo e(__('Views')); ?></li>
                    </ul>
                    <div class="blog_img">
                        <img src="<?php echo e(RvMedia::getImageUrl($post->image, null, false, RvMedia::getDefaultImage())); ?>" alt="<?php echo e($post->name); ?>">
                    </div>
                    <div class="blog_content">
                        <div class="blog_text">
                            <?php echo clean($post->content, 'youtube'); ?>

                            <div class="blog_post_footer">
                                <div class="row justify-content-between align-items-center">
                                    <div class="col-md-8 mb-3 mb-md-0">
                                        <div class="tags">
                                            <?php if(!$post->tags->isEmpty()): ?>
                                                <?php $__currentLoopData = $post->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <a href="<?php echo e($tag->url); ?>"><?php echo e($tag->name); ?></a>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <ul class="social_icons text-md-right">
                                            <li><a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo e(urlencode($post->url)); ?>&title=<?php echo e(rawurldecode($post->description)); ?>" target="_blank" title="<?php echo e(__('Share on Facebook')); ?>"><i class="ion-social-facebook"></i></a></li>
                                            <li><a href="https://twitter.com/intent/tweet?url=<?php echo e(urlencode($post->url)); ?>&text=<?php echo e(rawurldecode($post->description)); ?>" target="_blank" title="<?php echo e(__('Share on Twitter')); ?>"><i class="ion-social-twitter"></i></a></li>
                                            <li><a href="https://www.linkedin.com/shareArticle?mini=true&url=<?php echo e(urlencode($post->url)); ?>&summary=<?php echo e(rawurldecode($post->description)); ?>&source=Linkedin" title="<?php echo e(__('Share on Linkedin')); ?>" target="_blank"><i class="ion-social-linkedin"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <br>
                            <?php echo apply_filters(BASE_FILTER_PUBLIC_COMMENT_AREA, theme_option('facebook_comment_enabled_in_post', 'yes') == 'yes' ? Theme::partial('comments') : null); ?>

                        </div>
                    </div>
                </div>
                <?php $relatedPosts = get_related_posts($post->id, 2); ?>

                <?php if($relatedPosts->count()): ?>
                    <br>
                    <div class="related_post">
                        <div class="content_title">
                            <h5><?php echo e(__('Related posts')); ?></h5>
                        </div>
                        <div class="row">
                            <?php $__currentLoopData = $relatedPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $relatedItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-6">
                                    <div class="blog_post blog_style2 box_shadow1">
                                        <div class="blog_img">
                                            <a href="<?php echo e($relatedItem->url); ?>"><img src="<?php echo e(RvMedia::getImageUrl($relatedItem->image, 'small', false, RvMedia::getDefaultImage())); ?>" alt="<?php echo e($relatedItem->name); ?>"></a>
                                        </div>
                                        <div class="blog_content bg-white">
                                            <div class="blog_text">
                                                <h6 class="blog_title"><a href="<?php echo e($relatedItem->url); ?>"><?php echo e($relatedItem->name); ?></a></h6>
                                                <ul class="list_none blog_meta">
                                                    <li><i class="ti-calendar"></i> <?php echo e($relatedItem->created_at->translatedFormat('M d, Y')); ?></li>
                                                    <li><i class="ti-eye"></i> <?php echo e(number_format($relatedItem->views)); ?> <?php echo e(__('Views')); ?></li>
                                                </ul>
                                                <p><?php echo e(Str::limit($relatedItem->description, 110)); ?></p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
            <div class="col-xl-3 mt-4 pt-2 mt-xl-0 pt-xl-0">
                <div class="sidebar">
                    <?php echo dynamic_sidebar('primary_sidebar'); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\laravel-ecommerce-system\platform/themes/shopwise/views/post.blade.php ENDPATH**/ ?>