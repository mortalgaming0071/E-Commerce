<div class="row">
    <div class="col-6">
        <p><?php echo $label; ?>:</p>
    </div>
    <div class="col-6 float-right">
        <p class="price-text text-right"> <?php echo e($value); ?> </p>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\laravel-ecommerce-system\platform/plugins/ecommerce/resources/views//orders/thank-you/total-row.blade.php ENDPATH**/ ?>