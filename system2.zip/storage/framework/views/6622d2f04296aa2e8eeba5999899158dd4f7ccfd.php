<div class="form-group">
    <label for="icon" class="control-label"><?php echo e(__('Icon')); ?></label>
    <?php echo Form::themeIcon('icon', $icon, ['class' =>'form-control', 'id' => 'icon-select']); ?>

</div>
<?php /**PATH C:\xampp\htdocs\laravel-ecommerce-system\platform/themes/shopwise/partials/product-category-fields.blade.php ENDPATH**/ ?>