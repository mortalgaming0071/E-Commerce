<li class="list-group-item">
    <input
            class="magic-radio"
            type="radio"
            name="shipping_method"
            id="shipping-method-<?php echo e($shippingKey); ?>-<?php echo e($shippingOption); ?>"
            <?php if(old('shipping_method', $shippingKey) == $defaultShippingMethod && old('shipping_option', $shippingOption) == $defaultShippingOption): ?> checked <?php endif; ?>
            value="<?php echo e($shippingKey); ?>"
            data-option="<?php echo e($shippingOption); ?>"
    >
    <label for="shipping-method-<?php echo e($shippingKey); ?>-<?php echo e($shippingOption); ?>"><?php echo e($shippingItem['name']); ?> - <?php if($shippingItem['price'] > 0): ?> <?php echo e(format_price($shippingItem['price'])); ?> <?php else: ?> <strong><?php echo e(__('Free shipping')); ?></strong> <?php endif; ?></label>
</li>
<?php /**PATH C:\xampp\htdocs\laravel-ecommerce-system\platform/plugins/ecommerce/resources/views//orders/partials/shipping-option.blade.php ENDPATH**/ ?>