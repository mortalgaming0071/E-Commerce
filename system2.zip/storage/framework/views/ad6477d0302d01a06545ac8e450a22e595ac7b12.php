<?php Theme::set('pageName', __('Order Tracking')) ?>

<div class="section">
    <div class="container order-tracking-wrapper">
            <div class="row justify-content-center">
                <div class="col-md-6 col-sm-8 col-12">
                    <form method="GET" action="<?php echo e(route('public.orders.tracking')); ?>" class="tracking-form">
                        <div class="text-center">
                            <h3><?php echo e(__('Order tracking')); ?></h3>
                            <p><?php echo e(__('Tracking your order status')); ?></p>
                        </div>
                        <div class="form__content">
                            <div class="form-group">
                                <label for="txt-order-id"><?php echo e(__('Order ID')); ?><sup>*</sup></label>
                                <input class="form-control" name="order_id" id="txt-order-id" type="text" value="<?php echo e(old('order_id', request()->input('order_id'))); ?>" placeholder="<?php echo e(__('Order ID')); ?>">
                                <?php if($errors->has('order_id')): ?>
                                    <span class="text-danger"><?php echo e($errors->first('order_id')); ?></span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label for="txt-email"><?php echo e(__('Email Address')); ?><sup>*</sup></label>
                                <input class="form-control" name="email" id="txt-email" type="email" value="<?php echo e(old('email', request()->input('email'))); ?>" placeholder="<?php echo e(__('Your Email')); ?>">
                                <?php if($errors->has('email')): ?>
                                    <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                                <?php endif; ?>
                            </div>
                            <div class="form__actions">
                                <button type="submit" class="btn btn-fill-out btn-block"><?php echo e(__('Find')); ?></button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <?php if($order): ?>
                <div class="customer-order-detail">
                    <div class="row">
                        <div class="col-md-6">
                            <h5><?php echo e(__('Order information')); ?></h5>
                            <p>
                                <span><?php echo e(__('Order number')); ?>:</span>
                                <strong><?php echo e(get_order_code($order->id)); ?></strong>
                            </p>
                            <p>
                                <span><?php echo e(__('Time')); ?>:</span> <strong><?php echo e($order->created_at->translatedFormat('M d, Y h:m')); ?></strong>
                            </p>
                            <p>
                                <span><?php echo e(__('Order status')); ?>:</span> <strong><?php echo e($order->status->label()); ?></strong>
                            </p>

                            <p>
                                <span><?php echo e(__('Payment method')); ?>:</span> <strong> <?php echo e($order->payment->payment_channel->label()); ?> </strong>
                            </p>

                            <p>
                                <span><?php echo e(__('Payment status')); ?>:</span> <strong><?php echo e($order->payment->status->label()); ?></strong>
                            </p>

                        </div>
                        <div class="col-md-6 customer-information-box">
                            <h5><?php echo e(__('Customer information')); ?></h5>

                            <p>
                                <span><?php echo e(__('Full Name')); ?>:</span> <strong><?php echo e($order->address->name); ?> </strong>
                            </p>

                            <p>
                                <span><?php echo e(__('Phone')); ?>:</span> <strong><?php echo e($order->address->phone); ?> </strong>
                            </p>

                            <p>
                                <span><?php echo e(__('Address')); ?>:</span> <strong> <?php echo e($order->address->address); ?> </strong>
                            </p>

                            <p>
                                <span><?php echo e(__('City')); ?>:</span> <strong><?php echo e($order->address->city); ?> </strong>
                            </p>
                            <p>
                                <span><?php echo e(__('State')); ?>:</span> <strong> <?php echo e($order->address->state); ?> </strong>
                            </p>
                            <?php if(count(EcommerceHelper::getAvailableCountries()) > 1): ?>
                                <p>
                                    <span><?php echo e(__('Country')); ?>:</span> <strong> <?php echo e($order->address->country_name); ?> </strong>
                                </p>
                            <?php endif; ?>
                            <?php if(EcommerceHelper::isZipCodeEnabled()): ?>
                                <p>
                                    <span><?php echo e(__('Zip code')); ?>:</span> <strong> <?php echo e($order->address->zip_code); ?> </strong>
                                </p>
                            <?php endif; ?>
                        </div>
                    </div>
                    <br>
                    <h5><?php echo e(__('Order detail')); ?></h5>
                    <div>
                        <div class="table-responsive">
                            <table class="table table-striped table-hover">
                                <thead>
                                <tr>
                                    <th class="text-center">#</th>
                                    <th class="text-center"><?php echo e(__('Image')); ?></th>
                                    <th><?php echo e(__('Product')); ?></th>
                                    <th class="text-center"><?php echo e(__('Amount')); ?></th>
                                    <th class="text-right" style="width: 100px"><?php echo e(__('Quantity')); ?></th>
                                    <th class="price text-right"><?php echo e(__('Total')); ?></th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $order->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $orderProduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $product = get_products([
                                            'condition' => [
                                                'ec_products.status' => \Botble\Base\Enums\BaseStatusEnum::PUBLISHED,
                                                'ec_products.id' => $orderProduct->product_id,
                                            ],
                                            'take' => 1,
                                            'select' => [
                                                'ec_products.id',
                                                'ec_products.images',
                                                'ec_products.name',
                                                'ec_products.price',
                                                'ec_products.sale_price',
                                                'ec_products.sale_type',
                                                'ec_products.start_date',
                                                'ec_products.end_date',
                                                'ec_products.sku',
                                                'ec_products.is_variation',
                                            ],
                                        ]);
                                    ?>
                                    <?php if($product): ?>
                                        <tr>
                                            <td class="text-center"><?php echo e($key + 1); ?></td>
                                            <td class="text-center">
                                                <img src="<?php echo e(RvMedia::getImageUrl($product->image, 'thumb', false, RvMedia::getDefaultImage())); ?>" width="50" alt="<?php echo e($product->name); ?>"></td>
                                            <td>
                                                <?php echo e($product->name); ?> <?php if($product->sku): ?> (<?php echo e($product->sku); ?>) <?php endif; ?>
                                                <?php if($product->is_variation): ?>
                                                    <p style="margin-bottom: 0">
                                                        <small>
                                                            <?php $attributes = get_product_attributes($product->id) ?>
                                                            <?php if(!empty($attributes)): ?>
                                                                <?php $__currentLoopData = $attributes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attribute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php echo e($attribute->attribute_set_title); ?>: <?php echo e($attribute->title); ?><?php if(!$loop->last): ?>, <?php endif; ?>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            <?php endif; ?>
                                                        </small>
                                                    </p>
                                                <?php endif; ?>
                                                <?php if(!empty($orderProduct->options) && is_array($orderProduct->options)): ?>
                                                    <?php $__currentLoopData = $orderProduct->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if(!empty($option['key']) && !empty($option['value'])): ?>
                                                            <p style="margin-bottom: 0"><small><?php echo e($option['key']); ?>: <strong> <?php echo e($option['value']); ?></strong></small></p>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo e(format_price($orderProduct->price, $orderProduct->currency)); ?></td>
                                            <td class="text-center"><?php echo e($orderProduct->qty); ?></td>
                                            <td class="money text-right">
                                                <strong>
                                                    <?php echo e(format_price($orderProduct->price * $orderProduct->qty, $orderProduct->currency)); ?>

                                                </strong>
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>

                        <p>
                            <span><?php echo e(__('Shipping fee')); ?>:</span> <strong>  <?php echo e(format_price($order->shipping_amount, $order->currency_id)); ?> </strong>
                        </p>

                        <?php if(EcommerceHelper::isTaxEnabled()): ?>
                            <p>
                                <span><?php echo e(__('Tax')); ?>:</span> <strong> <?php echo e(format_price($order->tax_amount, $order->currency_id)); ?> </strong>
                            </p>
                        <?php endif; ?>

                        <p>
                            <span><?php echo e(__('Discount')); ?>: </span> <strong> <?php echo e(format_price($order->discount_amount)); ?></strong>
                            <?php if($order->discount_amount): ?>
                                <?php if($order->coupon_code): ?>
                                    (<?php echo __('Coupon code: ":code"', ['code' => Html::tag('strong', $order->coupon_code)->toHtml()]); ?>)
                                <?php elseif($order->discount_description): ?>
                                    (<?php echo e($order->discount_description); ?>)
                                <?php endif; ?>
                            <?php endif; ?>
                        </p>

                        <p>
                            <span><?php echo e(__('Total Amount')); ?>:</span> <strong> <?php echo e(format_price($order->amount, $order->currency_id)); ?> </strong>
                        </p>
                    </div>
            <?php elseif(request()->input('order_id') || request()->input('email')): ?>
                <p class="text-center text-danger"><?php echo e(__('Order not found!')); ?></p>
            <?php endif; ?>
        </section>
                </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\laravel-ecommerce-system\platform/themes/shopwise/views/ecommerce/order-tracking.blade.php ENDPATH**/ ?>