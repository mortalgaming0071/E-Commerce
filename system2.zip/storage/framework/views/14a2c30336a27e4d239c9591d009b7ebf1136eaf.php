<?php Theme::set('pageName', __('Reset Password')) ?>

<!-- START LOGIN SECTION -->
<div class="login_register_wrap section">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-xl-6 col-md-10">
                <div class="login_wrap">
                    <div class="padding_eight_all bg-white">
                        <div class="heading_s1">
                            <h3><?php echo e(__('Reset Password')); ?></h3>
                        </div>
                        <form method="POST" action="<?php echo e(route('customer.password.request')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <input class="form-control" name="email" id="txt-email" type="email" value="<?php echo e(old('email')); ?>" placeholder="<?php echo e(__('Your Email')); ?>">
                                <?php if($errors->has('email')): ?>
                                    <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <button type="submit" class="btn btn-fill-out btn-block"><?php echo e(__('Send Password Reset Link')); ?></button>
                            </div>

                            <?php if(session('status')): ?>
                                <div class="text-success">
                                    <?php echo e(session('status')); ?>

                                </div>
                            <?php endif; ?>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- END LOGIN SECTION -->
<?php /**PATH C:\xampp\htdocs\laravel-ecommerce-system\platform/themes/shopwise/views/ecommerce/customers/passwords/email.blade.php ENDPATH**/ ?>