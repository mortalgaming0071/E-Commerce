<div class="form-group">
    <label class="control-label"><?php echo e(__('Title')); ?></label>
    <input type="text" name="title" data-shortcode-attribute="title" class="form-control" placeholder="<?php echo e(__('Title')); ?>">
</div>
<?php /**PATH C:\xampp\htdocs\laravel-ecommerce-system\platform/themes/shopwise/partials/shortcodes/trending-products-admin-config.blade.php ENDPATH**/ ?>