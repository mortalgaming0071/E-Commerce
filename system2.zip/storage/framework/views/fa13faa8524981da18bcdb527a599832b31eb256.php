<div class="ui-select-wrapper">
    <?php
        Arr::set($selectAttributes, 'class', Arr::get($selectAttributes, 'class') . ' ui-select');
    ?>
    <select name="<?php echo e($name); ?>" class='form-control select2_google_fonts_picker'>
        <?php
            $field['options'] = config('core.base.general.google_fonts', []);
        ?>
        <?php $__currentLoopData = array_combine($field['options'], $field['options']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value='<?php echo e($key); ?>' <?php if($key == $selected): ?> selected <?php endif; ?>><?php echo e($value); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <svg class="svg-next-icon svg-next-icon-size-16">
        <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#select-chevron"></use>
    </svg>
</div>

<?php if (! $__env->hasRenderedOnce('04f8844a-f34b-4245-a5a0-89d417f83e29')): $__env->markAsRenderedOnce('04f8844a-f34b-4245-a5a0-89d417f83e29'); ?>
    <?php $__env->startPush('footer'); ?>
        <link href="https://fonts.googleapis.com/css?family=<?php echo e(implode('|', array_map('urlencode', $field['options']))); ?>" rel="stylesheet" type="text/css">
    <?php $__env->stopPush(); ?>
<?php endif; ?>

<?php /**PATH C:\xampp\htdocs\laravel-ecommerce-system\platform/core/base/resources/views//forms/partials/google-fonts.blade.php ENDPATH**/ ?>