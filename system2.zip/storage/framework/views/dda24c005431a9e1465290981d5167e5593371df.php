<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-lg-3  col-sm-6">
            <?php echo $__env->make('plugins/ecommerce::reports.partials.count-sell', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="col-lg-3  col-sm-6">
            <?php echo $__env->make('plugins/ecommerce::reports.partials.count-orders', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="col-lg-3  col-sm-6">
            <?php echo $__env->make('plugins/ecommerce::reports.partials.count-products', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="col-lg-3  col-sm-6">
            <?php echo $__env->make('plugins/ecommerce::reports.partials.count-customers', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>

    <div class="row">
        <div class="col-md-6 col-sm-12 widget_item" id="revenue-report" data-url="<?php echo e(route('ecommerce.report.revenue')); ?>">
            <div class="portlet light bordered portlet-no-padding">
                <div class="portlet-title">
                    <div class="caption">
                        <i class="icon-settings font-dark"></i>
                        <span class="caption-subject font-dark"><?php echo e(trans('plugins/ecommerce::reports.revenue_statistics')); ?></span>
                    </div>
                    <?php echo $__env->make('plugins/ecommerce::reports.tools', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="row portlet-body widget-content" style="padding: 15px !important;">

                </div>
            </div>
        </div>

        <div class="col-md-6 col-sm-12 widget_item" id="top-selling-products-report" data-url="<?php echo e(route('ecommerce.report.top-selling-products')); ?>">
            <div class="portlet light bordered portlet-no-padding">
                <div class="portlet-title">
                    <div class="caption">
                        <i class="icon-settings font-dark"></i>
                        <span class="caption-subject font-dark"><?php echo e(trans('plugins/ecommerce::reports.top_selling_products')); ?></span>
                    </div>
                    <?php echo $__env->make('plugins/ecommerce::reports.tools', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="row portlet-body widget-content equal-height" style="padding: 15px 30px !important;">
                    <?php echo $topSellingProducts->renderTable(); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('core/base::layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-ecommerce-system\platform/plugins/ecommerce/resources/views//reports/index.blade.php ENDPATH**/ ?>