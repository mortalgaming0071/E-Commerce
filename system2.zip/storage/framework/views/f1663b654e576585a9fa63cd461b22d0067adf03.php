<!-- START SECTION CLIENT LOGO -->
<div class="section pt-0 small_pb">
    <div class="container">
        <div class="heading_tab_header">
            <div class="heading_s2">
                <h4><?php echo clean($title); ?></h4>
            </div>
        </div>
        <featured-brands-component url="<?php echo e(route('public.ajax.featured-brands')); ?>"></featured-brands-component>
    </div>
</div>
<!-- END SECTION CLIENT LOGO -->
<?php /**PATH C:\xampp\htdocs\laravel-ecommerce-system\platform/themes/shopwise/partials/shortcodes/featured-brands.blade.php ENDPATH**/ ?>