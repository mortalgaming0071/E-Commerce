<div class="table-actions">
    <a href="#" class="btn btn-icon btn-sm btn-danger deleteDialog" data-toggle="tooltip" data-section="<?php echo e(route('reviews.destroy', $item->id)); ?>" role="button" data-original-title="<?php echo e(trans('core/base::tables.delete_entry')); ?>" >
        <i class="fa fa-trash"></i>
    </a>
</div><?php /**PATH C:\xampp\htdocs\laravel-ecommerce-system\platform/plugins/ecommerce/resources/views//reviews/partials/actions.blade.php ENDPATH**/ ?>