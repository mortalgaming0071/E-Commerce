<?php if(in_array(strtoupper($currency), ['NGN', 'GHS', 'USD', 'ZAR']) && get_payment_setting('status', PAYSTACK_PAYMENT_METHOD_NAME) == 1): ?>
    <li class="list-group-item">
        <input class="magic-radio js_payment_method" type="radio" name="payment_method" id="payment_<?php echo e(PAYSTACK_PAYMENT_METHOD_NAME); ?>"
               value="<?php echo e(PAYSTACK_PAYMENT_METHOD_NAME); ?>" data-toggle="collapse" data-target=".payment_<?php echo e(PAYSTACK_PAYMENT_METHOD_NAME); ?>_wrap"
               data-parent=".list_payment_method"
               <?php if(setting('default_payment_method') == PAYSTACK_PAYMENT_METHOD_NAME): ?> checked <?php endif; ?>
        >
        <label for="payment_<?php echo e(PAYSTACK_PAYMENT_METHOD_NAME); ?>"><?php echo e(get_payment_setting('name', PAYSTACK_PAYMENT_METHOD_NAME)); ?></label>
        <div class="payment_<?php echo e(PAYSTACK_PAYMENT_METHOD_NAME); ?>_wrap payment_collapse_wrap collapse <?php if(setting('default_payment_method') == PAYSTACK_PAYMENT_METHOD_NAME): ?> show <?php endif; ?>">
            <p><?php echo get_payment_setting('description', PAYSTACK_PAYMENT_METHOD_NAME, __('Payment with Paystack')); ?></p>
        </div>
    </li>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\laravel-ecommerce-system\platform/plugins/paystack/resources/views//methods.blade.php ENDPATH**/ ?>