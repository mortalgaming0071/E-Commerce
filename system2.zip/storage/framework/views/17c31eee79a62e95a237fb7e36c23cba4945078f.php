<div class="half-circle-spinner loading-spinner">
    <div class="circle circle-1"></div>
    <div class="circle circle-2"></div>
</div>
<?php /**PATH C:\xampp\htdocs\laravel-ecommerce-system\platform/core/base/resources/views//elements/loading.blade.php ENDPATH**/ ?>