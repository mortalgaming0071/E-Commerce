<div class="facebook-comment">
    <div class="fb-comments" data-href="<?php echo e(Request::url()); ?>" data-numposts="5" data-width="100%"></div>
</div>
<?php /**PATH C:\xampp\htdocs\laravel-ecommerce-system\platform/themes/shopwise/partials/comments.blade.php ENDPATH**/ ?>