<div class="rating_wrap d-inline-block">
    <div class="rating">
        <div class="product_rate" style="width: <?php echo e($star * 20); ?>%"></div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\laravel-ecommerce-system\platform/plugins/ecommerce/resources/views//reviews/partials/rating.blade.php ENDPATH**/ ?>