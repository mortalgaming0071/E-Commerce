<?php $__env->startSection('content'); ?>
    <?php Theme::set('pageName', __('Account details')) ?>
    <div class="card">
        <div class="card-header">
            <h3><?php echo e(__('Account information')); ?></h3>
        </div>
        <div class="card-body">
            <?php echo Form::open(['route' => 'customer.edit-account']); ?>

                <div class="form-group">
                    <label for="name"><?php echo e(__('Full Name')); ?>:</label>
                    <input id="name" type="text" class="form-control" name="name" value="<?php echo e(auth('customer')->user()->name); ?>">
                </div>
                <?php echo Form::error('name', $errors); ?>


                <div class="form-group <?php if($errors->has('dob')): ?> has-error <?php endif; ?>">
                    <label for="date_of_birth"><?php echo e(__('Date of birth')); ?>:</label>
                    <input id="date_of_birth" type="text" class="form-control" name="dob" value="<?php echo e(auth('customer')->user()->dob); ?>">
                </div>
                <?php echo Form::error('dob', $errors); ?>

                <div class="form-group <?php if($errors->has('email')): ?> has-error <?php endif; ?>">
                    <label for="email"><?php echo e(__('Email')); ?>:</label>
                    <input id="email" type="text" class="form-control" disabled="disabled" value="<?php echo e(auth('customer')->user()->email); ?>" name="email">
                </div>
                <?php echo Form::error('email', $errors); ?>


                <div class="form-group <?php if($errors->has('phone')): ?> has-error <?php endif; ?>">
                    <label for="phone"><?php echo e(__('Phone')); ?></label>
                    <input type="text" class="form-control" name="phone" id="phone" placeholder="<?php echo e(__('Phone')); ?>" value="<?php echo e(auth('customer')->user()->phone); ?>">

                </div>
                <?php echo Form::error('phone', $errors); ?>


                <div class="form-group text-center">
                    <button type="submit" class="btn btn-fill-out btn-sm"><?php echo e(__('Update')); ?></button>
                </div>
            <?php echo Form::close(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make(Theme::getThemeNamespace() . '::views.ecommerce.customers.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-ecommerce-system\platform/themes/shopwise/views/ecommerce/customers/edit-account.blade.php ENDPATH**/ ?>