<div class="tools">
    <a href="#" class="expand" data-toggle="tooltip" title="<?php echo e(trans('core/dashboard::dashboard.collapse_expand')); ?>"></a>
    <a href="#" class="reload" data-toggle="tooltip" title="<?php echo e(trans('core/dashboard::dashboard.reload')); ?>"></a>
    <a href="#" class="fullscreen" data-toggle="tooltip" data-original-title="<?php echo e(trans('core/dashboard::dashboard.fullscreen')); ?>" title="<?php echo e(trans('core/dashboard::dashboard.fullscreen')); ?>"> </a>
</div><?php /**PATH C:\xampp\htdocs\laravel-ecommerce-system\platform/plugins/ecommerce/resources/views//reports/tools.blade.php ENDPATH**/ ?>